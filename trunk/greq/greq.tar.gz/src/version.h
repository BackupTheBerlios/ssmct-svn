#define GREQ_VERSION "greq 0.9.4 (C)2002 by Felix Braun\n"
