/* src/config.h.  Generated automatically by configure.  */
/* src/config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "greq"

/* Version number of package */
#define VERSION "0.9.4"

